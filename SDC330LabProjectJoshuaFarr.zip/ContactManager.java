import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Name: Joshua Farr
 * Date: August 1, 2026
 * Purpose: Stores and manages the application's contacts.
 * This class provides methods for adding, removing, updating,
 * displaying, and searching contacts.
 * also learned about shift-alt-f for formatting code in VS Code, and shift-alt-o for organizing the code
 * which made it look very clean and professional :)
 */

public class ContactManager {

    // List to store all contacts
    private ArrayList<Contact> contacts;

    // Constructor to initialize the contacts list and add sample contacts
    public ContactManager() {
        contacts = new ArrayList<>();

        addSampleContacts();

    }

    // Method to add sample contacts to the list
    private void addSampleContacts() {

        Address businessAddress = new Address(
                "100 Main Street",
                "Richmond",
                "VA",
                "23220");

        BusinessContact businessContact = new BusinessContact(
                "Jose",
                "Franks",
                "804-555-1100",
                "jose.franks@example.com",
                businessAddress,
                "Blank City Industries",
                "Software Developer");

        Address familyAddress = new Address(
                "240 Oak Avenue",
                "Richmond",
                "VA",
                "23221");

        FamilyContact familyContact = new FamilyContact(
                "Daniel",
                "Farr",
                "804-555-2200",
                "daniel.farr@example.com",
                familyAddress,
                "Cousin");

        Address friendAddress = new Address(
                "125 Forest Lane",
                "Richmond",
                "VA",
                "23225");

        FriendContact friendContact = new FriendContact(
                "Rebecca",
                "Phillips",
                "804-555-3300",
                "rebecca.phillips@example.com",
                friendAddress,
                "Met in college");
        // Add the sample contacts to the contacts list
        contacts.add(businessContact);
        contacts.add(familyContact);
        contacts.add(friendContact);
    }

    // Method to add a new contact based on user input
    public void addContact(Scanner scanner) {

        // Display the contact type options to the user
        System.out.println();
        System.out.println("ADD A CONTACT:");
        System.out.println("1. Business Contact");
        System.out.println("2. Family Contact");
        System.out.println("3. Friend Contact");
        System.out.println("0. Return to main menu");

        // Prompt the user to select a contact type
        int contactType = readNumber(
                scanner,
                "Select a contact type: ",
                0,
                3);

        // If the user selects 0, return to the main menu
        if (contactType == 0) {
            return; // Return to main menu
        }

        String firstName = readRequiredText(
                scanner,
                "Enter first name: ");

        String lastName = readRequiredText(
                scanner,
                "Enter last name: ");

        String phoneNumber = readRequiredText(
                scanner,
                "Enter phone number: ");

        String emailAddress = readRequiredText(
                scanner,
                "Enter email address: ");

        String streetAddress = readRequiredText(
                scanner,
                "Enter street address: ");

        String city = readRequiredText(
                scanner,
                "Enter city: ");

        String state = readRequiredText(
                scanner,
                "Enter state: ");

        String zipCode = readRequiredText(
                scanner,
                "Enter ZIP code: ");

        Address address = new Address(
                streetAddress,
                city,
                state,
                zipCode);

        // Create a new contact based on the selected contact type
        Contact newContact;

        // Use a switch statement to handle different contact types
        switch (contactType) {

            // Create a BusinessContact if the user selected option 1
            case 1:
                String companyName = readRequiredText(
                        scanner,
                        "Enter company name: ");

                String jobTitle = readRequiredText(
                        scanner,
                        "Enter job title: ");

                newContact = new BusinessContact(
                        firstName,
                        lastName,
                        phoneNumber,
                        emailAddress,
                        address,
                        companyName,
                        jobTitle);
                break;
            // Create a FamilyContact if the user selected option 2
            case 2:
                String relationship = readRequiredText(
                        scanner,
                        "Enter relationship: ");

                newContact = new FamilyContact(
                        firstName,
                        lastName,
                        phoneNumber,
                        emailAddress,
                        address,
                        relationship);
                break;

            // Create a FriendContact if the user selected option 3
            case 3:
                String howWeMet = readRequiredText(
                        scanner,
                        "Enter how you met: ");

                newContact = new FriendContact(
                        firstName,
                        lastName,
                        phoneNumber,
                        emailAddress,
                        address,
                        howWeMet);
                break;

            // If the user selected an invalid option, return to the main menu
            default:
                return;
        }
        // Add the newly created contact to the contacts list
        contacts.add(newContact);

        // Display a confirmation message to the user
        System.out.println();
        System.out.println(
                newContact.getFullName()
                        + " was successfully added.");
    }

    // The contact removal method allows the user to select and remove a contact
    // from the list.
    // It prompts for confirmation before deletion and provides feedback on the
    // action taken.
    public void removeContact(Scanner scanner) {

        System.out.println();
        System.out.println("REMOVE A CONTACT");

        Contact selectedContact = selectContact(scanner);

        if (selectedContact == null) {
            return;
        }

        System.out.print(
                "Are you sure you want to remove "
                        + selectedContact.getFullName()
                        + "? Enter Y or N: ");

        String confirmation = scanner.nextLine().trim();

        if (confirmation.equalsIgnoreCase("Y")) {
            contacts.remove(selectedContact);

            // Display a confirmation message to the user
            System.out.println(
                    selectedContact.getFullName()
                            + " was successfully removed.");

        } else {
            System.out.println("Removal canceled.");
        }
    }

    // The contact update method allows the user to select a contact and update its
    // information.
    // It provides a menu of fields that can be updated and prompts the user for new
    // values
    public void updateContact(Scanner scanner) {
        System.out.println();
        System.out.println("UPDATE A CONTACT");

        Contact selectedContact = selectContact(scanner);

        // If no contact is selected, return to the main menu
        if (selectedContact == null) {
            return;
        }

        System.out.println();
        System.out.println(
                "Updating contact: " + selectedContact.getFullName());

        // Display the update options to the user
        System.out.println("1. First name");
        System.out.println("2. Last name");
        System.out.println("3. Phone number");
        System.out.println("4. Email address");
        System.out.println("5. Street address");
        System.out.println("6. City");
        System.out.println("7. State");
        System.out.println("8. ZIP code");
        System.out.println("9. Contact-specific information");
        System.out.println("0. Cancel");

        int fieldChoice = readNumber(
                scanner,
                "Select a field to update: ",
                0,
                9);

        switch (fieldChoice) {
            case 1:
                selectedContact.setFirstName(
                        readRequiredText(
                                scanner,
                                "Enter the new first name: "));
                break;
            case 2:
                selectedContact.setLastName(
                        readRequiredText(
                                scanner,
                                "Enter the new last name: "));
                break;
            case 3:
                selectedContact.setPhoneNumber(
                        readRequiredText(
                                scanner,
                                "Enter the new phone number: "));
                break;
            case 4:
                selectedContact.setEmailAddress(
                        readRequiredText(
                                scanner,
                                "Enter the new email address: "));
                break;
            case 5:
                selectedContact.getAddress().setStreetAddress(
                        readRequiredText(
                                scanner,
                                "Enter the new street address: "));
                break;
            case 6:
                selectedContact.getAddress().setCity(
                        readRequiredText(
                                scanner,
                                "Enter the new city: "));
                break;
            case 7:
                selectedContact.getAddress().setState(
                        readRequiredText(
                                scanner,
                                "Enter the new state: "));
                break;
            case 8:
                selectedContact.getAddress().setZipCode(
                        readRequiredText(
                                scanner,
                                "Enter the new ZIP code: "));
                break;
            case 9:
                // Update contact-specific information based on the contact type
                updateContactSpecificInformation(
                        scanner,
                        selectedContact);
                break;
            case 0:
                System.out.println("Update canceled.");
                return;
            default:
                System.out.println("Invalid choice. Update canceled.");
                return;
        }

        System.out.println("Contact updated successfully.");
    }

    // The updateContactSpecificInformation method handles the updating of
    // contact-specific fields based on the type of contact (Business, Family, or
    // Friend).
    private void updateContactSpecificInformation(
            Scanner scanner,
            Contact selectedContact) {

        if (selectedContact instanceof BusinessContact) {

            BusinessContact businessContact = (BusinessContact) selectedContact;

            System.out.println("1. Company name");
            System.out.println("2. Job title");

            int choice = readNumber(
                    scanner,
                    "Select a field to update: ",
                    1,
                    2);

            if (choice == 1) {
                businessContact.setCompanyName(
                        readRequiredText(
                                scanner,
                                "Enter the new company name: "));
            } else {
                businessContact.setJobTitle(
                        readRequiredText(
                                scanner,
                                "Enter the new job title: "));
            }
        } else if (selectedContact instanceof FamilyContact) {

            FamilyContact familyContact = (FamilyContact) selectedContact;

            familyContact.setRelationship(
                    readRequiredText(
                            scanner,
                            "Enter the new relationship: "));
        } else if (selectedContact instanceof FriendContact) {

            FriendContact friendContact = (FriendContact) selectedContact;

            friendContact.setHowWeMet(
                    readRequiredText(
                            scanner,
                            "Enter the new 'How we met' description: "));
        }

    }

    // The displayAllContacts method displays a summary of all contacts in the list,
    public void displayAllContacts() {

        System.out.println();
        System.out.println("ALL CONTACTS");

        displayContactSummary(contacts);

        for (Contact contact : contacts) {
            contact.displayContactInformation();
        }
    }

    // The displayContactsByType method allows the user to filter and display
    // contacts based on their type (Business, Family, or Friend).
    public void displayContactsByType(Scanner scanner) {

        System.out.println();
        System.out.println("DISPLAY CONTACTS BY TYPE");
        System.out.println("1. Business contacts");
        System.out.println("2. Family contacts");
        System.out.println("3. Friend contacts");
        System.out.println("0. Return to main menu");

        int choice = readNumber(
                scanner,
                "Select a contact type: ",
                0,
                3);

        if (choice == 0) {
            return;
        }

        String selectedType;

        switch (choice) {
            case 1:
                selectedType = "Business";
                break;

            case 2:
                selectedType = "Family";
                break;

            case 3:
                selectedType = "Friend";
                break;

            default:
                return;
        }

        ArrayList<Contact> matchingContacts = new ArrayList<>();

        for (Contact contact : contacts) {
            if (contact.getContactType().equalsIgnoreCase(selectedType)) {
                matchingContacts.add(contact);
            }
        }

        System.out.println();
        System.out.println(selectedType.toUpperCase() + " CONTACTS");

        displayContactSummary(matchingContacts);

        for (Contact contact : matchingContacts) {
            contact.displayContactInformation();
        }
    }

    // The searchContactsByLastNameLetter method allows the user to search for
    // contacts whose last names begin with a specific letter.
    public void searchContactsByLastNameLetter(Scanner scanner) {

        System.out.println();
        System.out.println("SEARCH BY LAST-NAME LETTER");

        String searchText = readRequiredText(
                scanner,
                "Enter the first letter of the last name: ");

        char searchLetter = Character.toUpperCase(searchText.charAt(0));

        ArrayList<Contact> matchingContacts = new ArrayList<>();

        for (Contact contact : contacts) {

            // Check if the last name is not empty before accessing its first character
            if (!contact.getLastName().isEmpty()) {

                // Convert the first letter of the last name to uppercase for comparison
                char firstLetter = Character.toUpperCase(
                        contact.getLastName().charAt(0));

                // Compare the first letter of the last name with the search letter
                if (firstLetter == searchLetter) {
                    matchingContacts.add(contact);
                }
            }
        }

        // Display the search results to the user
        System.out.println();
        System.out.println(
                "CONTACTS WHOSE LAST NAME BEGINS WITH "
                        + searchLetter);

        displayContactSummary(matchingContacts);

        for (Contact contact : matchingContacts) {
            contact.displayContactInformation();
        }
    }

    // The displayContactSummary method provides a concise summary of the contacts
    // in the provided list, including their ID, name, type, and phone number.
    private void displayContactSummary(
            List<Contact> contactsToDisplay) {

        if (contactsToDisplay.isEmpty()) {
            System.out.println("No matching contacts were found.");
            return;
        }

        // we use printf to format the output in a tabular manner, ensuring that the
        // columns align properly for better readability.
        System.out.printf(
                // We use %-4s, %-24s, %-12s, and %-15s to specify the width of each column and
                // left-align the text within those columns.
                "%-4s %-24s %-12s %-15s%n",
                "ID",
                "Name",
                "Type",
                "Phone");

        System.out.println(
                "------------------------------------------------------------");

        for (int index = 0; index < contactsToDisplay.size(); index++) {

            Contact contact = contactsToDisplay.get(index);

            System.out.printf(
                    "%-4d %-24s %-12s %-15s%n",
                    index + 1,
                    contact.getFullName(),
                    contact.getContactType(),
                    contact.getPhoneNumber());
        }
    }

    // The selectContact method allows the user to select a contact from the list by
    // displaying
    // a summary of available contacts and prompting for a selection, and prompting
    // them for an answer.
    private Contact selectContact(Scanner scanner) {

        if (contacts.isEmpty()) {
            System.out.println("There are no contacts available.");
            return null;
        }

        displayContactSummary(contacts);

        int selection = readNumber(
                scanner,
                "Enter a contact ID, or 0 to cancel: ",
                0,
                contacts.size());

        if (selection == 0) {
            return null;
        }

        return contacts.get(selection - 1);
    }

    private int readNumber(
            Scanner scanner,
            String prompt,
            int minimum,
            int maximum) {

        while (true) {

            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            try {

                // Convert the input to an integer and check if it's within the specified range
                int number = Integer.parseInt(input);

                if (number >= minimum && number <= maximum) {
                    return number;
                }

                System.out.println(
                        "Please enter a number from "
                                + minimum
                                + " through "
                                + maximum
                                + ".");
                // Handles the cases where the user enters a non-integer value, prompting them
                // to enter a valid whole number.
            } catch (NumberFormatException exception) {
                System.out.println(
                        "Invalid entry. Please enter a whole number.");
            }
        }
    }

    private String readRequiredText(

            Scanner scanner,
            String prompt) {

        while (true) {

            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            // Check if the input is not empty; if it's not, return the input
            if (!input.isEmpty()) {
                return input;
            }
            // If the input is empty, display an error message and prompt again
            System.out.println(
                    "This field cannot be left blank.");
        }
    }
}
