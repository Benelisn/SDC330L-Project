import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Name: Joshua Farr
 * Date: 8/4/2026
 * Purpose: Stores and manages the application's follow-up reminders.
 * mirrors the role ContactManager plays for
 * contacts - this class owns the list of reminders and provides methods
 * for adding and displaying them.
 */

public class ReminderManager {

    // Requires the exact MM/DD/YYYY shape and, with STRICT resolving,
    // rejects calendar-impossible dates like 02/30/2026 instead of rolling them over
    private static final DateTimeFormatter DUE_DATE_FORMAT =
            DateTimeFormatter.ofPattern("MM/dd/uuuu")
                    .withResolverStyle(ResolverStyle.STRICT);

    // List to store all reminders
    private ArrayList<FollowUpReminder> reminders;

    // Needs access to the contacts so a reminder can be attached
    private ContactManager contactManager;

    // Constructor
    public ReminderManager(ContactManager contactManager) {
        this.contactManager = contactManager;
        this.reminders = new ArrayList<>();

        addSampleReminders();

    }

    // Method to add a couple of sample reminders using the sample contacts
    private void addSampleReminders() {
        ArrayList<Contact> existingContacts = contactManager.getContacts();

        if (existingContacts.size() >= 2) {

            reminders.add(new FollowUpReminder(
                existingContacts.get(0),
                "Calling back about that project",
                "8/20/2026"));

            reminders.add(new FollowUpReminder(
                existingContacts.get(1),
                "What are we doing for thanksgiving?",
                "11/4/2026"));
        }
    }

    // Method to add a new reminder based on user input
    public void addReminder(Scanner scanner) {

        System.out.println();
        System.out.println("Add a follow up reminder");

        Contact selectedContact = contactManager.selectContact(scanner);

        if (selectedContact == null) {
            return;
        }

        System.out.print("Enter a reminder note: ");
        String note = scanner.nextLine().trim();

        String duedate = readDueDate(scanner);

        FollowUpReminder newReminder = new FollowUpReminder(
                    selectedContact, 
                    note, 
                    duedate);

        reminders.add(newReminder);

        System.out.println();
        System.out.println("Reminder for " + selectedContact.getFullName() 
                + " was successfully added. ");
    }

    // Repeatedly prompts until the user enters a real calendar date in
    // MM/DD/YYYY
    private String readDueDate(Scanner scanner) {

        while (true) {

            System.out.print("Enter a due date (MM/DD/YYYY): ");
            String input = scanner.nextLine().trim();

            try {
                LocalDate parsed = LocalDate.parse(input, DUE_DATE_FORMAT);

                if (parsed.isBefore(LocalDate.now())) {
                    System.out.println(
                            "That date has already passed. Please enter a date of today or later.");
                    continue;
                }

                return input;
            } catch (DateTimeParseException exception) {
                System.out.println(
                        "That is not a valid date. Please use MM/DD/YYYY, e.g. 08/20/2026.");
            }
        }
    }

    // The displayReminders method shows every stored reminder.
    public void displayReminders() {

        System.out.println();
        System.out.println("FOLLOW-UP REMINDERS");

        if (reminders.isEmpty()) {
            System.out.println("There are no reminders yet.");
            return;
        }

        // Each reminder is treated as a remindable here. The loop only knows its calling getReminderMessage() on a remindable
        for (int index = 0; index < reminders.size(); index++) {
            Remindable reminder = reminders.get(index);
            System.out.println(
                    (index + 1) + ". " + reminder.getReminderMessage());
        }
    }

    // Method to delete a reminder chosen by the user
    public void deleteReminder(Scanner scanner) {

        System.out.println();
        System.out.println("DELETE A REMINDER");

        if (reminders.isEmpty()) {
            System.out.println("There are no reminders to delete.");
            return;
        }

        displayReminders();

        System.out.print(
                "Enter the number of the reminder to delete, or 0 to cancel: ");

        String input = scanner.nextLine().trim();
        int choice;

        try {
            choice = Integer.parseInt(input);
        } catch (NumberFormatException exception) {
            System.out.println("That is not a valid number.");
            return;
        }

        if (choice == 0) {
            System.out.println("Deletion canceled.");
            return;
        }

        if (choice < 1 || choice > reminders.size()) {
            System.out.println("There is no reminder with that number.");
            return;
        }

        FollowUpReminder selectedReminder = reminders.get(choice - 1);

        System.out.print(
                "Are you sure you want to delete this reminder? Enter Y or N: ");

        String confirmation = scanner.nextLine().trim();

        if (confirmation.equalsIgnoreCase("Y")) {
            reminders.remove(selectedReminder);
            System.out.println("Reminder successfully deleted.");
        } else {
            System.out.println("Deletion canceled.");
        }
    }
}