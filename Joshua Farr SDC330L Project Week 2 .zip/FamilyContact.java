/**
 * Name: Joshua Farr
 * Date: August 1, 2026
 * Description: Stores information for a family contact.
 * This class demonstrates inheritance by extending Contact.
 */


public class FamilyContact extends Contact {

    //Variables specific to FamilyContact
    private String relationship;

    //Constructor to later create and initialize objects
    public FamilyContact(String firstName, String lastName,
                         String phoneNumber, String emailAddress, 
                         Address address, String relationship) {

        super(firstName, lastName, phoneNumber, emailAddress, address);

        this.relationship = relationship;
    }                    

    //getters and setters methods to access and modify the private variables
    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    //Override the getContactType() and getAdditionalInformation() methods to provide specific information for FamilyContact
    @Override
    public String getContactType() {
        return "Family";
    }

    @Override
    public String getAdditionalInformation() {
        return "Relationship: " + relationship;
    }
    
    // overrides the generic version in Contact to include the relationship.
    @Override
    public String generateReport() {
        return "Family: " + getFullName() + " (" + relationship + ")";
    }
    
}
