/**
 * Name: Joshua Farr
 * Date: August 8, 2026
 * Purpose: Defines a contract for anything that can produce a
 * human-readable reminder message.
 *
 * Implemented by the new FollowUpReminder class. 
 * Defining it separately means ReminderManager
 * never has to know it is specifically holding a FollowUpReminder - only
 * that it is holding "something that can describe itself as a reminder."
 * That leaves room to add other kinds of reminders later without
 * changing ReminderManager at all.
 */

public interface Remindable {

    // Returns a ready-to-display reminder message.
    String getReminderMessage();
}