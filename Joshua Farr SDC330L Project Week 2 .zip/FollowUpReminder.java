/**
 * Name: Joshua Farr
 * Date: August 8, 2026
 * Description: Represents a single follow-up reminder tied to an
 * existing contact. New for Project Week 2.
 *
 * Composition
 * A FollowUpReminder HAS A Contact - it is meaningless without one, and
 * it stores a reference to an existing contact rather than copying that
 * contact's name/phone/email itself. This is a second example
 * of composition beyond Contact HAS AN Address from Week 1.
 *
 * Interface
 * Implements Remindable so ReminderManager can work with reminders in
 * general, without needing to know this is the only kind that exists.
 */

public class FollowUpReminder implements Remindable {

    // Composition holds a reference to an existing Contact instead of
    // duuplicating that contacts information

    private Contact contact;

    private String note;
    private String dueDate;

    // Contstructor
    public FollowUpReminder(Contact contact, String note, String dueDate) {
        this.contact = contact;
        this.note = note;
        this.dueDate = dueDate;

    }

    // getter methods
    public Contact getContact() {
        return contact;
    }

    public String getNote() {
        return note;
    }

    public String getDueDate() {
        return dueDate;
    }

    // Polymorphism ReminderManager calls this method through remindable reference
    @Override
    public String getReminderMessage() {
        return "Follow up with " + contact.getFullName()
                + " by " + dueDate + ": " + note;
    }
}
