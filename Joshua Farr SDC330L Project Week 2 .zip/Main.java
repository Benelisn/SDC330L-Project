import java.util.Scanner;

/**
 * Name: Joshua Farr
 * Date: August 1, 2026
 * Description: Starts the Personal Contact Manager application,
 * displays the user interface, and processes menu selections.
 */

public class Main {
    public static void main(String[] args) throws Exception {

        // Scannerreads info entered by the user
        Scanner scanner = new Scanner(System.in);

        // ContactManager stores contacts and performs contact operations
        ContactManager contactManager = new ContactManager();

        // ReminderManager stores follow-up reminders, new for Week 2
        ReminderManager reminderManager = new ReminderManager(contactManager);

        // Controls whether the application's main menu contiunues to be displayed
        boolean running = true;

        // Displays the welcome message
        displayWelcome();

        // Continue displaying the menu until the user chooses to exit
        while (running) {

            displayMainMenu();

            // Read the user's menu choice
            int menuChoice = readMenuChoice(scanner);

            // Process the user's menu choice
            switch (menuChoice) {

                case 1:
                    contactManager.addContact(scanner);
                    pauseProgram(scanner);
                    break;

                case 2:
                    contactManager.removeContact(scanner);
                    pauseProgram(scanner);
                    break;

                case 3:
                    contactManager.updateContact(scanner);
                    pauseProgram(scanner);
                    break;

                case 4:
                    contactManager.displayAllContacts();
                    pauseProgram(scanner);
                    break;

                case 5:
                    contactManager.displayContactsByType(scanner);
                    pauseProgram(scanner);
                    break;

                case 6:
                    contactManager.searchContactsByLastNameLetter(scanner);
                    pauseProgram(scanner);
                    break;

                case 7:
                    contactManager.generateContactReports();
                    pauseProgram(scanner);
                    break;

                case 8:
                    contactManager.exportContacts();
                    pauseProgram(scanner);
                    break;

                case 9:
                    reminderManager.addReminder(scanner);
                    pauseProgram(scanner);
                    break;

                case 10:
                    reminderManager.displayReminders();
                    pauseProgram(scanner);
                    break;

                case 11:
                    reminderManager.deleteReminder(scanner);
                    pauseProgram(scanner);
                    break;

                case 0:
                    System.out.println("Exiting the application. Goodbye!");
                    running = false;
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
        System.out.println();
        System.out.println(
                "Thank you for using the Personal Contact Manager.");
        System.out.println("Goodbye!");

        scanner.close();
    }

    /**
     * Displays the project heading, welcome message, and instructions.
     */
    private static void displayWelcome() {

        System.out.println(
                "============================================================");
        System.out.println("                       PROJECT WEEK 2");
        System.out.println(
                "       INHERITANCE, COMPOSITION, AND USER INTERACTIONS");
        System.out.println("                PERSONAL CONTACT MANAGER");
        System.out.println("                     Joshua Farr");
        System.out.println(
                "============================================================");

        System.out.println();
        System.out.println(
                "Welcome to the Personal Contact Manager.");

        System.out.println(
                "This program is designed to help you organize and manage");

        System.out.println(
                "your family, friend, and business contacts.");

        System.out.println();
        System.out.println("INSTRUCTIONS:");
        System.out.println(
                "- Type the number beside a menu option.");
        System.out.println(
                "- Press Enter after making a selection.");
        System.out.println(
                "- Follow the prompts when adding or changing information.");
        System.out.println(
                "- Enter 0 from the main menu to exit.");
    }

    /**
     * Displays the application's main menu.
     */
    private static void displayMainMenu() {

        System.out.println();
        System.out.println("==================== MAIN MENU ====================");

        System.out.println("1. Add a contact");
        System.out.println("2. Remove a contact");
        System.out.println("3. Update a contact");
        System.out.println("4. Display all contacts");
        System.out.println("5. Display contacts by type");
        System.out.println("6. Search contacts by last-name letter");
        System.out.println("7. Generate contact reports");
        System.out.println("8. Export contacts");
        System.out.println("9. Add a reminder");
        System.out.println("10. Display reminders");
        System.out.println("11. Delete a follow-up reminder");
        System.out.println("0. Exit");

        System.out.println(
                "===================================================");
    }

    /**
     * Reads and validates the user's main-menu selection.
     *
     * @param scanner reads input entered by the user
     * @return a valid menu selection from 0 through 11
     */
    private static int readMenuChoice(Scanner scanner) {

        while (true) {

            System.out.print("Enter your selection: ");

            String input = scanner.nextLine().trim();

            try {

                int menuChoice = Integer.parseInt(input);

                if (menuChoice >= 0 && menuChoice <= 11) {
                    return menuChoice;
                }

                System.out.println(
                        "Please enter a number from 0 through 11.");

            } catch (NumberFormatException exception) {

                System.out.println(
                        "Invalid entry. Please enter a whole number.");
            }
        }
    }

    /**
     * Pauses the program so the user can review the displayed information.
     *
     * @param scanner reads when the user presses Enter
     */
    private static void pauseProgram(Scanner scanner) {

        System.out.println();
        System.out.print(
                "Press Enter to return to the main menu...");

        scanner.nextLine();
    }

}
