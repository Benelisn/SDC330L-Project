/**
 * Name: Joshua Farr
 * Date: August 1, 2026
 * Description: Stores information for a friend contact.
 * This class demonstrates inheritance by extending Contact.
 */

public class FriendContact extends Contact {

    // Variables specific to FriendContact
    private String howWeMet;

    // Constructor to later create and initialize objects
    public FriendContact(String firstName, String lastName,
            String phoneNumber, String emailAddress,
            Address address, String howWeMet) {

        super(firstName, lastName, phoneNumber, emailAddress, address);

        this.howWeMet = howWeMet;
    }

    // getters and setters methods to access and modify the private variables
    public String getHowWeMet() {
        return howWeMet;
    }

    public void setHowWeMet(String howWeMet) {
        this.howWeMet = howWeMet;
    }

    // Override the getContactType() and getAdditionalInformation() methods to
    // provide specific information for FriendContact
    @Override
    public String getContactType() {
        return "Friend";
    }

    @Override
    public String getAdditionalInformation() {
        return "How We Met: " + howWeMet;
    }

    // overrides the generic version in Contact to include how the two met.
    @Override
    public String generateReport() {
        return "Friend: " + getFullName() + " (" + howWeMet + ")";
    }

}
