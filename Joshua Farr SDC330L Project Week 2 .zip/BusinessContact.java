/**
 * Name: Joshua Farr
 * Date: August 1, 2026
 * Description: Stores information for a business contact.
 * This class demonstrates inheritance by extending the Contact class.
 */

public class BusinessContact extends Contact {

    // Variables specific to BusinessContact
    private String companyName;
    private String jobTitle;

    // Constructor to later create and initialize objects
    public BusinessContact(String firstName, String lastName,
            String phoneNumber, String emailAddress,
            Address address, String companyName,
            String jobTitle) {

        super(firstName, lastName, phoneNumber, emailAddress, address);

        this.companyName = companyName;
        this.jobTitle = jobTitle;

    }

    // getters and setters methods to access and modify the private variables
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    // Override the getContactType() and getAdditionalInformation() methods to
    // provide specific information for BusinessContact
    @Override
    public String getContactType() {
        return "Business";
    }

    @Override
    public String getAdditionalInformation() {
        return "Company Name: " + companyName
                + "\nJob Title: " + jobTitle;

    }

    // overrides the generic version in Contact to include company and job title.
    @Override
    public String generateReport() {
        return "Business: " + getFullName() + " - " + jobTitle
                + " @ " + companyName;
    }

}
