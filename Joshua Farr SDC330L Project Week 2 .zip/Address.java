/**
 * Name: Joshua Farr
 * Date: August 1, 2026
 * Description: Stores the street address information for a contact.
 * This class demonstrates composition because a Contact has an Address.
 * 
 * It also helps to demonstrate Composition as "A Contact HAS AN Address"
 */

public class Address {
        //encapsulation of variables
    private String streetAddress;
    private String city;
    private String state;
    private String zipCode;
        //constructor to later create and initialize objects 
    public Address(String streetAddress, String city, String state, String zipCode) {
        this.streetAddress = streetAddress;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
    }
        //getters and setters methods to access and modify the private variables
    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

        // Override the toString() method to choose how to 
        // display the address information when printing an Address object
       
    @Override
    public String toString() {
        return streetAddress + ", " 
        + city + ", " 
        + state + " " 
        + zipCode;
    }

}