/**
 * Name: Joshua Farr
 * Date: August 1, 2026
 * Description: Stores information shared by all contact types.
 * This class serves as the base class for Business Contact, 
 * Family Contact, and Friend Contact to inherit from. 
 * It demonstrates inheritance because the 
 * other contact types will inherit from this class.
 */

//Now implements Reportable, Exportable
public class Contact implements Reportable, Exportable {

    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String emailAddress;


    //Composition: A Contact HAS AN Address
    private Address address;

    //Constructor to later create and initialize objects
    public Contact(String firstName, String lastName,
                   String phoneNumber, String emailAddress, 
                   Address address) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.address = address;
    }
    
    //getters and setters methods to access and modify the private variables
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public String getEmailAddress() {
        return emailAddress;
    }
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
    public Address getAddress() {
        return address;
    }
    public void setAddress(Address address) {
        this.address = address;
    }
    //Additional methods to get full name, contact type, and additional information
    public String getFullName() {
        return firstName + " " + lastName;
    }
    //these two methods will be overridden in subclasses to provide specific contact type information
    public String getContactType() {
        return "General Contact";
    }
    public String getAdditionalInformation() {
        return "";
    }
    //Displays the contact information in a formatted manner
        public void displayContactInformation() {
        System.out.println("--------------------------------------------");
        System.out.println("Contact Type: " + getContactType());
        System.out.println("Name: " + getFullName());
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Email: " + emailAddress);
        System.out.println("Address: " + address);

        String additionalInfo = getAdditionalInformation();
        
    //checks if additional information is available and displays it if present
        if (!additionalInfo.isEmpty()) {
            System.out.println("Additional Information: " + additionalInfo);
        }

         System.out.println("--------------------------------------------");
    }

    //Two new overrides for our interfaces we just implemented
    //Reportable interface implementaion 
    //Each of the Contact types override this method to include their own extra fieldss
     @Override
    public String generateReport() {
        return getContactType() + ": " + getFullName()
                + " - " + phoneNumber;
    }

    // Exportable interface implementation 
    // This method is not overridden in subclasses but still returns subclass specific data
      @Override
    public String[] toRecord() {
        return new String[] {
                getContactType(),
                firstName,
                lastName,
                phoneNumber,
                emailAddress,
                address.getStreetAddress(),
                address.getCity(),
                address.getState(),
                address.getZipCode(),
                getAdditionalInformation()
        };
    }


}
