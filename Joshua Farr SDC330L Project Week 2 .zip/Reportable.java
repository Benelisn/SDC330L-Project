/**
 * Name: Joshua Farr
 * Date: August 8, 2026
 * Purpose: Defines a contract for any class that can produce a short,
 * human-readable summary of itself.
 *
 * This is one of the interfaces required for Project Week 2. It exists
 * separately from the Contact class hierarchy on purpose - "being able
 * to summarize yourself" is a capability, not a type of contact, so it
 * belongs in an interface rather than being hard-coded into Contact.
 */

public interface Reportable {

    // Any implementing class supplies its own version of this method,
    // returning a one-line summary suitable for a quick report view.
    String generateReport();

}