/**
 * Name: Joshua Farr
 * Date: August 8, 2026
 * Purpose: Defines a contract for any class that can flatten its data
 * into a row of plain field values, suitable for writing to a CSV file
 * today and, eventually, a database table.
 *
 * This is the second interface
 * Like Reportable, it describes what an object can DO "export yourself as a
 * record" rather than what the object IS, which is what makes it a
 * good fit for an interface instead of a base class.
 */

public interface Exportable {

    // Returns this object's fields as an array of Strings, in a fixed
    // column order, so callers can write them out without needing to
    // know the concrete type producing them.
    String[] toRecord();
}